from .gemini import generate
from .fallback import home_plan, party_plan, jewelry_plan
from .catalog import search_url

def normalize(result, planner):
    for item in result.get("recommendations", []):
        item["estimated_price"] = float(item.get("estimated_price", 0))
        item["search_url"] = search_url(item.get("platform","Amazon"), item.get("name","product"))
    result["planner"] = planner
    result["ai_generated"] = bool(result.get("ai_generated", False))
    return result

def make_recommendation(planner, data, image_bytes=None, mime_type=None):
    ai=generate(planner, data, image_bytes, mime_type)
    if ai:
        ai["ai_generated"]=True
        return normalize(ai, planner)
    if planner=="home":
        return normalize(home_plan(data), planner)
    if planner=="party":
        return normalize(party_plan(data), planner)
    return normalize(jewelry_plan(data, bool(image_bytes)), planner)
