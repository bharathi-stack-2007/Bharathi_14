from datetime import datetime, timedelta, timezone
import jwt
from werkzeug.security import generate_password_hash, check_password_hash
from fastapi import HTTPException, Request
from ..config import SECRET_KEY, SESSION_DAYS
from ..db import get_connection

ALGORITHM = "HS256"

def create_token(user_id: int):
    exp = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    return jwt.encode({"sub": str(user_id), "exp": exp}, SECRET_KEY, algorithm=ALGORITHM)

def decode_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return int(payload["sub"])
    except Exception:
        return None

def register_user(name, email, password):
    password_hash = generate_password_hash(password)
    with get_connection() as conn:
        try:
            cur = conn.execute(
                "INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                (name.strip(), email.lower().strip(), password_hash),
            )
            return cur.lastrowid
        except Exception as exc:
            if "UNIQUE" in str(exc).upper():
                raise ValueError("An account with this email already exists.")
            raise

def authenticate(email, password):
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM users WHERE email=?", (email.lower().strip(),)).fetchone()
    if not row or not check_password_hash(row["password_hash"], password):
        return None
    return dict(row)

def current_user(request: Request):
    token = request.cookies.get("access_token") or request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
    if not token:
        return None
    user_id = decode_token(token)
    if not user_id:
        return None
    with get_connection() as conn:
        row = conn.execute("SELECT id,name,email,created_at FROM users WHERE id=?", (user_id,)).fetchone()
    return dict(row) if row else None

def require_user(request: Request):
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Login required.")
    return user
