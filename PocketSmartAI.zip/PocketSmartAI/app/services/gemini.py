import base64, json
from typing import Any
from pydantic import BaseModel, Field
from google import genai
from google.genai import types
from ..config import GEMINI_API_KEY, GEMINI_MODEL

class AIItem(BaseModel):
    category: str
    name: str
    description: str
    estimated_price: float = Field(ge=0)
    platform: str
    reason: str
    budget_fit: str

class AIResponse(BaseModel):
    summary: str
    budget_breakdown: dict[str, float]
    tips: list[str]
    recommendations: list[AIItem]

def _client():
    if not GEMINI_API_KEY:
        return None
    return genai.Client(api_key=GEMINI_API_KEY)

def _prompt(planner: str, data: dict[str, Any], image_present=False):
    return f"""
You are PocketSmart AI, a careful budget recommendation assistant.
Planner: {planner}
User input: {json.dumps(data, ensure_ascii=False)}
Image supplied: {image_present}

Return recommendations for the user's stated budget. Do not invent live inventory,
stock status, exact current prices, ratings, reviews, or availability. Estimated prices
must be clearly treated as estimates. Platform must be one of:
Amazon, Flipkart, IKEA, Swiggy, Zomato, OYO.
For {planner}, choose only platforms that make sense.
Give 4-8 useful recommendations. Budget breakdown values must sum approximately to the
total budget. Keep descriptions concise. Mention uncertainty when appropriate.
For jewelry image input, use only visible, non-sensitive styling information such as
dominant colors, garment type, neckline or overall aesthetic. Do not identify the person.

Input fields:
{json.dumps(data, ensure_ascii=False, indent=2)}
"""

def generate(planner, data, image_bytes=None, mime_type=None):
    client=_client()
    if not client:
        return None
    contents=[_prompt(planner, data, bool(image_bytes))]
    if image_bytes:
        contents.append(types.Part.from_bytes(data=image_bytes, mime_type=mime_type or "image/jpeg"))
    try:
        response=client.models.generate_content(
            model=GEMINI_MODEL,
            contents=contents,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=AIResponse,
                temperature=0.35,
                max_output_tokens=2500,
            ),
        )
        if getattr(response, "parsed", None):
            return response.parsed.model_dump()
        return AIResponse.model_validate_json(response.text).model_dump()
    except Exception:
        return None
