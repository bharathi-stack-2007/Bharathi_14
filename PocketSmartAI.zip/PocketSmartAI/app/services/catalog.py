from urllib.parse import quote_plus

# These are source/search adapters rather than claims of live inventory.
# Replace with official partner APIs when credentials/contracts are available.
PLATFORMS = {
    "Amazon": "https://www.amazon.in/s?k={q}",
    "Flipkart": "https://www.flipkart.com/search?q={q}",
    "IKEA": "https://www.ikea.com/in/en/search/?q={q}",
    "Swiggy": "https://www.swiggy.com/search?query={q}",
    "Zomato": "https://www.zomato.com/search?query={q}",
    "OYO": "https://www.oyorooms.com/search?q={q}",
}

def search_url(platform, query):
    template = PLATFORMS.get(platform, PLATFORMS["Amazon"])
    return template.format(q=quote_plus(query))

def platform_for(planner, category):
    if planner == "home":
        return ["IKEA", "Amazon", "Flipkart"][(hash(category) % 3)]
    if planner == "party":
        if category.lower() in {"food", "catering"}:
            return ["Swiggy", "Zomato"][hash(category) % 2]
        if category.lower() in {"venue", "stay"}:
            return "OYO"
        return "Amazon"
    return ["Amazon", "Flipkart"][hash(category) % 2]
