from .catalog import platform_for, search_url

def _item(planner, category, name, price, description, reason, budget_fit):
    platform = platform_for(planner, category)
    return {
        "category": category,
        "name": name,
        "description": description,
        "estimated_price": round(float(price), 2),
        "platform": platform,
        "search_url": search_url(platform, name),
        "reason": reason,
        "budget_fit": budget_fit,
    }

def home_plan(data):
    budget = data["budget"]
    room = data["room"]
    items = data.get("items") or ["lighting", "storage", "decor"]
    unit = budget / max(len(items), 1)
    recs = []
    for i, item in enumerate(items[:8]):
        price = min(unit * (0.65 + i * 0.05), budget)
        recs.append(_item("home", item, f"{data['style'].title()} {item.title()} for {room}",
                          price, f"Budget-conscious {item} idea for a {data['style']} {room}.",
                          "Balances practical use with the requested style.", "Within the planned budget"))
    return {
        "planner":"home","budget":budget,
        "summary":f"A practical {data['style']} {room} setup using {len(recs)} selected categories.",
        "budget_breakdown":{"Furniture & storage":budget*.45,"Lighting":budget*.20,"Decor":budget*.20,"Buffer":budget*.15},
        "tips":["Keep 10–15% as a buffer for delivery and small extras.","Compare dimensions before buying furniture.","Use one main style and repeat 2–3 accent colors."],
        "recommendations":recs,"ai_generated":False
    }

def party_plan(data):
    budget=data["budget"]; guests=data["guests"]
    recs=[
        _item("party","Food","Catering / food package",budget*.45,"Food plan sized around the guest count.",
              "Largest share goes to food so the per-guest budget stays realistic.","Within budget"),
        _item("party","Decoration","Simple event decoration package",budget*.18,"Theme-friendly decoration with controlled spend.",
              "Keeps decoration attractive without taking too much of the budget.","Within budget"),
        _item("party","Venue","Venue / stay search",budget*.22,"Venue or nearby stay options based on the event details.",
              "Leaves room for the venue while protecting food and contingency.","Within budget"),
        _item("party","Entertainment","Music and activity setup",budget*.10,"Basic entertainment or activity allowance.",
              "Provides a small entertainment allocation without overspending.","Within budget"),
    ]
    return {"planner":"party","budget":budget,
            "summary":f"A starter {data['event_type']} plan for {guests} guests with a balanced allocation.",
            "budget_breakdown":{"Food":budget*.45,"Decoration":budget*.18,"Venue":budget*.22,"Entertainment":budget*.10,"Buffer":budget*.05},
            "tips":["Confirm venue capacity and taxes before booking.","Get per-person catering quotes.","Keep a small contingency for last-minute needs."],
            "recommendations":recs,"ai_generated":False}

def jewelry_plan(data, image_present=False):
    budget=data["budget"]
    recs=[
        _item("jewelry","Earrings",f"{data['style'].title()} earrings",budget*.20,"A versatile pair suited to the stated occasion and style.",
              "Easy to coordinate with the selected outfit and occasion.","Within budget"),
        _item("jewelry","Necklace",f"{data['style'].title()} necklace",budget*.45,"A main necklace option with a controlled budget share.",
              "Acts as the primary statement piece while leaving room for other accessories.","Within budget"),
        _item("jewelry","Bangles",f"{data['style'].title()} bangles set",budget*.20,"A matching bangle set.",
              "Adds coordination without consuming the full budget.","Within budget"),
        _item("jewelry","Ring",f"{data['style'].title()} ring",budget*.10,"A small coordinating accessory.",
              "Completes the look with a modest allocation.","Within budget"),
    ]
    image_note=" The outfit image was received; add the AI model to analyze visible colors and styling." if image_present else ""
    return {"planner":"jewelry","budget":budget,
            "summary":f"Jewelry ideas for a {data['occasion']} occasion in a {data['style']} style.{image_note}",
            "budget_breakdown":{"Necklace":budget*.45,"Earrings":budget*.20,"Bangles":budget*.20,"Ring":budget*.10,"Buffer":budget*.05},
            "tips":["Match metal tone to the outfit and occasion.","Check size, material and return policy before buying.","Treat prices as estimates until confirmed on the platform."],
            "recommendations":recs,"ai_generated":False}
