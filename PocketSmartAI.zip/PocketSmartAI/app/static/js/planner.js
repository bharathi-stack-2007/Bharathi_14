function money(v){return Number(v||0).toLocaleString("en-IN",{maximumFractionDigits:0})}
function renderResult(d){
 const el=document.querySelector("#results");
 const breakdown=Object.entries(d.budget_breakdown||{}).map(([k,v])=>`<div class="card"><b>${k}</b><div class="price">₹${money(v)}</div></div>`).join("");
 const recs=(d.recommendations||[]).map(x=>`<article class="card"><div class="row"><span>${x.category}</span><span class="badge">${x.platform}</span></div><h3>${x.name}</h3><p>${x.description}</p><div class="price">₹${money(x.estimated_price)}</div><p class="muted">${x.reason}</p><a class="btn small" target="_blank" rel="noopener" href="${x.search_url}">View/search on ${x.platform}</a></article>`).join("");
 el.innerHTML=`<div class="card result-head"><div><p class="eyebrow">RESULT</p><h2>${d.summary}</h2></div><span class="badge">${d.ai_generated?"Gemini AI":"Local fallback"}</span></div><h3>Budget allocation</h3><div class="grid three">${breakdown}</div><h3>Recommendations</h3><div class="rec-grid">${recs}</div><div class="card"><h3>Tips</h3><ul>${(d.tips||[]).map(x=>`<li>${x}</li>`).join("")}</ul></div>`;
}
document.querySelector("#plannerForm").addEventListener("submit",async e=>{
 e.preventDefault(); const form=e.target, msg=document.querySelector("#formMsg"); msg.textContent="Generating...";
 let body, opts={method:"POST",headers:{}};
 if(window.PLANNER==="jewelry"){body=new FormData(form)}else{
  const raw=Object.fromEntries(new FormData(form)); if(window.PLANNER==="home") raw.items=(raw.items||"").split(",").map(x=>x.trim()).filter(Boolean);
  body=JSON.stringify(raw); opts.headers["Content-Type"]="application/json";
 }
 opts.body=body;
 const r=await fetch(`/api/generate-${window.PLANNER}`,opts); const d=await r.json();
 if(r.ok){msg.textContent="";renderResult(d);document.querySelector("#results").scrollIntoView({behavior:"smooth"})}
 else msg.textContent=d.detail||"Something went wrong. Please try again.";
});