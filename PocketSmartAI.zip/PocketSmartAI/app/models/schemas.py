from typing import Literal, Optional
from pydantic import BaseModel, EmailStr, Field

PlannerType = Literal["home", "party", "jewelry"]

class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)

class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)

class HomeRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    room: str = Field(min_length=2, max_length=80)
    style: str = Field(default="modern", max_length=80)
    items: list[str] = Field(default_factory=list, max_length=20)
    notes: str = Field(default="", max_length=500)

class PartyRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    guests: int = Field(gt=0, le=10000)
    event_type: str = Field(min_length=2, max_length=80)
    venue: str = Field(default="", max_length=120)
    food_preference: str = Field(default="mixed", max_length=80)
    notes: str = Field(default="", max_length=500)

class JewelryRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    occasion: str = Field(min_length=2, max_length=80)
    style: str = Field(default="elegant", max_length=80)
    outfit_color: str = Field(default="", max_length=80)
    notes: str = Field(default="", max_length=500)

class RecommendationItem(BaseModel):
    category: str
    name: str
    description: str
    estimated_price: float = Field(ge=0)
    platform: str
    search_url: str
    reason: str
    budget_fit: str

class RecommendationResponse(BaseModel):
    planner: PlannerType
    budget: float
    summary: str
    budget_breakdown: dict[str, float]
    tips: list[str]
    recommendations: list[RecommendationItem]
    ai_generated: bool = False
