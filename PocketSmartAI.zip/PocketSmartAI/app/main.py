from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from .config import APP_NAME, STATIC_DIR, TEMPLATES_DIR, UPLOAD_DIR
from .db import init_db
from .routes.auth import router as auth_router
from .routes.api import router as api_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    UPLOAD_DIR.mkdir(exist_ok=True)
    init_db()
    yield

app=FastAPI(title=APP_NAME, version="1.0.0", lifespan=lifespan)
app.mount("/static",StaticFiles(directory=STATIC_DIR),name="static")
templates=Jinja2Templates(directory=TEMPLATES_DIR)
app.include_router(auth_router)
app.include_router(api_router)

@app.get("/",response_class=HTMLResponse)
def home(request:Request):
    return templates.TemplateResponse("index.html",{"request":request,"app_name":APP_NAME})

@app.get("/planner/{planner}",response_class=HTMLResponse)
def planner(request:Request,planner:str):
    if planner not in {"home","party","jewelry"}:
        from fastapi import HTTPException
        raise HTTPException(404,"Planner not found")
    return templates.TemplateResponse(f"{planner}.html",{"request":request,"app_name":APP_NAME,"planner":planner})

@app.get("/login",response_class=HTMLResponse)
def login_page(request:Request):
    return templates.TemplateResponse("login.html",{"request":request,"app_name":APP_NAME})

@app.get("/register",response_class=HTMLResponse)
def register_page(request:Request):
    return templates.TemplateResponse("register.html",{"request":request,"app_name":APP_NAME})

@app.get("/dashboard",response_class=HTMLResponse)
def dashboard(request:Request):
    return templates.TemplateResponse("dashboard.html",{"request":request,"app_name":APP_NAME})

@app.get("/history",response_class=HTMLResponse)
def history_page(request:Request):
    return templates.TemplateResponse("history.html",{"request":request,"app_name":APP_NAME})

@app.get("/health")
def health():
    return {"status":"ok","service":APP_NAME}

if __name__=="__main__":
    import uvicorn
    uvicorn.run("app.main:app",host="127.0.0.1",port=8000,reload=True)
