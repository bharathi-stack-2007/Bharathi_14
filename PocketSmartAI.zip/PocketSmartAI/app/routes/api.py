import json
from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from ..db import get_connection
from ..models.schemas import HomeRequest, PartyRequest, JewelryRequest
from ..services.auth import require_user
from ..services.recommendation import make_recommendation
from ..config import MAX_UPLOAD_MB

router=APIRouter(prefix="/api")

def save_history(user_id, planner, request_data, result):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO recommendation_history(user_id,planner,request_json,response_json) VALUES(?,?,?,?,?)",
            (user_id,planner,json.dumps(request_data),json.dumps(result))
        )

@router.post("/generate-home")
def generate_home(payload: HomeRequest, request: Request):
    user=require_user(request)
    data=payload.model_dump()
    result=make_recommendation("home",data)
    save_history(user["id"],"home",data,result)
    return result

@router.post("/generate-party")
def generate_party(payload: PartyRequest, request: Request):
    user=require_user(request)
    data=payload.model_dump()
    result=make_recommendation("party",data)
    save_history(user["id"],"party",data,result)
    return result

@router.post("/generate-jewelry")
async def generate_jewelry(
    request: Request,
    budget: float = Form(...),
    occasion: str = Form(...),
    style: str = Form("elegant"),
    outfit_color: str = Form(""),
    notes: str = Form(""),
    outfit_image: UploadFile | None = File(None),
):
    user=require_user(request)
    if budget <= 0: raise HTTPException(422,"Budget must be greater than zero.")
    image_bytes=None; mime=None
    if outfit_image and outfit_image.filename:
        if outfit_image.content_type not in {"image/jpeg","image/png","image/webp"}:
            raise HTTPException(415,"Upload a JPG, PNG or WebP image.")
        image_bytes=await outfit_image.read()
        if len(image_bytes) > MAX_UPLOAD_MB*1024*1024:
            raise HTTPException(413,f"Image must be {MAX_UPLOAD_MB} MB or smaller.")
        mime=outfit_image.content_type
    data={"budget":budget,"occasion":occasion.strip(),"style":style.strip(),
          "outfit_color":outfit_color.strip(),"notes":notes.strip()}
    result=make_recommendation("jewelry",data,image_bytes,mime)
    save_history(user["id"],"jewelry",data,result)
    return result

@router.get("/history")
def history(request: Request):
    user=require_user(request)
    with get_connection() as conn:
        rows=conn.execute(
            "SELECT id,planner,request_json,response_json,created_at FROM recommendation_history WHERE user_id=? ORDER BY id DESC LIMIT 30",
            (user["id"],)
        ).fetchall()
    return [dict(r) for r in rows]

@router.get("/session-info")
def session_info(request: Request):
    user=require_user(request)
    return {"logged_in":True,"user":user}

@router.get("/session-data")
def session_data(request: Request):
    user=require_user(request)
    with get_connection() as conn:
        count=conn.execute("SELECT COUNT(*) c FROM recommendation_history WHERE user_id=?", (user["id"],)).fetchone()["c"]
    return {"user_id":user["id"],"recommendation_count":count}
