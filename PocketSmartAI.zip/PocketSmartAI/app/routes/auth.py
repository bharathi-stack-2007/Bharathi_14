from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from ..models.schemas import RegisterRequest, LoginRequest
from ..services.auth import register_user, authenticate, create_token, current_user

router=APIRouter()

@router.post("/register")
def register(payload:RegisterRequest):
    try:
        user_id=register_user(payload.name,payload.email,payload.password)
    except ValueError as e:
        raise HTTPException(409,str(e))
    token=create_token(user_id)
    response=JSONResponse({"message":"Registration successful","user_id":user_id})
    response.set_cookie("access_token",token,httponly=True,samesite="lax",max_age=7*24*3600)
    return response

@router.post("/login")
def login(payload:LoginRequest):
    user=authenticate(payload.email,payload.password)
    if not user: raise HTTPException(401,"Invalid email or password.")
    token=create_token(user["id"])
    response=JSONResponse({"message":"Login successful","user":{"id":user["id"],"name":user["name"],"email":user["email"]}})
    response.set_cookie("access_token",token,httponly=True,samesite="lax",max_age=7*24*3600)
    return response

@router.post("/logout")
def logout():
    response=JSONResponse({"message":"Logged out"})
    response.delete_cookie("access_token")
    return response

@router.get("/me")
def me(request:Request):
    user=current_user(request)
    return {"logged_in":bool(user),"user":user}

@router.post("/token")
def token(payload:LoginRequest):
    user=authenticate(payload.email,payload.password)
    if not user: raise HTTPException(401,"Invalid email or password.")
    return {"access_token":create_token(user["id"]),"token_type":"bearer"}
