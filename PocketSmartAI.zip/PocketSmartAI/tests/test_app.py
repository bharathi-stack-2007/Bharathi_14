import os
os.environ["DATABASE_PATH"]="/tmp/pocketsmart_test.db"
os.environ["SECRET_KEY"]="test-secret"
from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)

def test_health():
    r=client.get("/health")
    assert r.status_code==200
    assert r.json()["status"]=="ok"

def test_register_login():
    email="test@example.com"
    client.post("/register",json={"name":"Test User","email":email,"password":"secret123"})
    r=client.post("/login",json={"email":email,"password":"secret123"})
    assert r.status_code==200
    assert client.get("/me").json()["logged_in"] is True

def test_home_requires_login():
    r=client.post("/api/generate-home",json={"budget":50000,"room":"Bedroom","style":"Modern","items":["bed","lights"],"notes":""})
    assert r.status_code==401
