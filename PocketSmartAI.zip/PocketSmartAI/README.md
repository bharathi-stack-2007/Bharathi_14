# PocketSmart AI — Smart Budget & Recommendation Assistant

A complete FastAPI + Jinja2 + JavaScript project based on the supplied PocketSmart AI documentation.

## What is included

- Home Interior planner
- Party Budget planner
- Jewelry planner with optional outfit-image upload
- Gemini multimodal recommendation layer
- Local rule-based fallback when `GEMINI_API_KEY` is not configured or Gemini is unavailable
- Register / login / logout
- JWT token endpoint
- HTTP-only login cookie for the browser
- SQLite recommendation history
- Dashboard and history pages
- Responsive frontend
- Input validation
- Automated API tests
- Configurable Gemini model
- Platform search adapters for Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO

### Important product-data note

The supplied documentation describes links to third-party platforms but does not provide official API credentials or contracts. This implementation therefore creates platform search links instead of pretending to have live inventory/pricing. For production integrations, replace `app/services/catalog.py` with the official APIs/affiliate APIs available to your account.

## 1. Requirements

- Python 3.11+
- VS Code
- Internet connection if you want Gemini
- A Gemini API key for AI mode

## 2. VS Code setup

Open the `PocketSmartAI` folder in VS Code.

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

Open `.env` and set:

```env
SECRET_KEY=replace-with-a-long-random-string
GEMINI_API_KEY=your-key-here
GEMINI_MODEL=gemini-2.5-flash
```

If you leave `GEMINI_API_KEY` empty, the application still works using the built-in fallback recommender.

## 3. Run

```bash
uvicorn app.main:app --reload
```

Open:

`http://127.0.0.1:8000`

API docs:

`http://127.0.0.1:8000/docs`

Health check:

`http://127.0.0.1:8000/health`

## 4. Test

```bash
pytest -q
```

Manual flow:

1. Register.
2. Open Home / Party / Jewelry planner.
3. Enter a budget and other details.
4. Generate recommendations.
5. For Jewelry, optionally upload JPG/PNG/WebP outfit image.
6. Open History to see saved plans.
7. Open Dashboard to see plan count.

## 5. API routes

### Authentication

- `POST /register`
- `POST /login`
- `POST /logout`
- `POST /token`
- `GET /me`

### Planners

- `POST /api/generate-home`
- `POST /api/generate-party`
- `POST /api/generate-jewelry`

### Session/history

- `GET /api/session-info`
- `GET /api/session-data`
- `GET /api/history`

## 6. Architecture

```text
Browser
  |
  | HTML + CSS + JavaScript
  v
FastAPI
  |---- Auth service ---- SQLite users
  |---- Recommendation service
  |       |---- Gemini service (optional)
  |       |---- Local fallback
  |       `---- Platform search adapters
  `---- History service ---- SQLite
```

## 7. Gemini mode

The code uses Google's `google-genai` SDK and a configurable current Gemini model. The planner asks for structured JSON and the Jewelry planner can send an image together with the text prompt.

If your account/model availability differs, change `GEMINI_MODEL` in `.env` without changing the application code.

## 8. Security notes

- Passwords are hashed with Werkzeug.
- Browser authentication uses an HTTP-only cookie containing a signed JWT.
- Do not commit `.env`.
- Use HTTPS and a strong secret key in production.
- Add CSRF protection, rate limiting, production logging and a production database before public deployment.
- Do not treat AI-generated prices or product availability as authoritative.

## 9. Extending to real partner APIs

Keep the planner and AI layers unchanged. Implement official partner API clients inside `app/services/catalog.py`, then return verified product/service records with current prices, IDs and URLs. Do not scrape sites where their terms prohibit it.
